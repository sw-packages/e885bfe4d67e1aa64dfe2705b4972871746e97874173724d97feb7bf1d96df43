<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>QQuickPlatformDialog</name>
    <message>
        <source>Dialog is an abstract base class</source>
        <translation>對話框為抽象基礎類別</translation>
    </message>
    <message>
        <source>Cannot create an instance of StandardButton</source>
        <translation>無法建立 StandardButton 的實例</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2ImagineStylePlugin</name>
    <message>
        <source>Imagine is an attached property</source>
        <translation>Imagine 為附加屬性</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2MaterialStylePlugin</name>
    <message>
        <source>Material is an attached property</source>
        <translation>Material 為附加屬性</translation>
    </message>
</context>
<context>
    <name>QtQuickControls2UniversalStylePlugin</name>
    <message>
        <source>Universal is an attached property</source>
        <translation>Universal 為附加屬性</translation>
    </message>
</context>
</TS>
